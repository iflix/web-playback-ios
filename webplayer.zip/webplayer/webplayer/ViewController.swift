//
//  ViewController.swift
//  webplayer
//
//  Created by Tim Kreger on 26/3/19.
//  Copyright © 2019 iflix. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet weak var VideoView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Add your url here
        if let videoURL:URL = URL(string: "https://iflix-videocdn-p1.akamaized.net/5a518/22221.ism/manifest.m3u8?idx=0&assetId=22221&userId=v_33-i_433961") {
            let request:URLRequest = URLRequest(url: videoURL)
            VideoView.load(request)
        }
    }


}

